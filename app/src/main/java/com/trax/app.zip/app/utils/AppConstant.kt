package com.trax.app.utils

object AppConstant {

    var CredentialsRemember = false
    const val CURRENT_USER ="user"
    const val EMAIL = "email"
    const val PASSWORD = "pass"
    const val ISREMEMBER = "isRemember"
    const val IS_LOGIN = "isLogin"
    const val USER_NAME = "name"
    const val USER_EMAIL = "user_email"
    const val USER_ACCOUNT_ID = "account_id"
    const val USER_PROFILE_ID = "profile_id"
    const val AUTH_TOKEN = "auth_token"

    var DOWNLOAD_ID = ""
    const val secretKey = "tK5UTui+DPh8lIlBxya5XVsmeDCoUl6vHhdIESMB6sQ="
    const val salt = "QWlGNHNhMTJTQWZ2bGhpV3U="
    const val iv = "bVQzNFNhRkQ1Njc4UUFaWA=="

}