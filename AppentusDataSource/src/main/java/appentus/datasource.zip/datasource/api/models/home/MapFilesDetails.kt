package appentus.datasource.api.models.home

data class MapFilesDetails(
    val mapFileID:Int,
    val mapFile:String,
    val mapFileName:String,
    val mapInfoJson:String
)
