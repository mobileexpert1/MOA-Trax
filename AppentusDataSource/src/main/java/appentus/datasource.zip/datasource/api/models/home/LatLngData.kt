package appentus.datasource.api.models.home

class LatLngData {

       var latLngList: ArrayList<LatLng> = ArrayList()


}


class LatLng {

    var lat:Double?= null

    var lng:Double?= null

}